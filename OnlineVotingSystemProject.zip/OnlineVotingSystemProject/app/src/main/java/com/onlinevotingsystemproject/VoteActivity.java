package com.onlinevotingsystemproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class VoteActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private Button submitButton;
    private DatabaseHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vote);

        radioGroup = findViewById(R.id.radioGroup_options);
        submitButton = findViewById(R.id.button_submit);
        dbHelper = new DatabaseHelper(this);

        userId = getUserId(); // Retrieve user ID from shared preferences or intent

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                if (selectedId == -1) {
                    Toast.makeText(VoteActivity.this, "Please select a party", Toast.LENGTH_SHORT).show();
                    return;
                }
                RadioButton selectedRadioButton = findViewById(selectedId);
                String selectedParty = selectedRadioButton.getText().toString();
                int partyId = getPartyId(selectedParty);
                if (partyId != -1 && userId != -1) {
                    saveVote(userId, partyId);
                    Toast.makeText(VoteActivity.this, "Vote submitted!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(VoteActivity.this, ResultsActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(VoteActivity.this, "Error submitting vote", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private int getUserId() {
        // Retrieve user ID from shared preferences or intent
        // For demonstration, return a dummy value
        return 1; // Example user ID
    }

    @SuppressLint("Range")
    private int getPartyId(String partyName) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_PARTIES,
                new String[]{DatabaseHelper.COLUMN_PARTY_ID},
                DatabaseHelper.COLUMN_PARTY_NAME + "=?",
                new String[]{partyName},
                null, null, null);

        int partyId = -1;
        if (cursor.moveToFirst()) {
            partyId = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_PARTY_ID));
        }
        cursor.close();
        db.close();
        return partyId;
    }

    private void saveVote(int userId, int partyId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USER_ID_FK, userId);
        values.put(DatabaseHelper.COLUMN_PARTY_ID_FK, partyId);
        db.insert(DatabaseHelper.TABLE_VOTES, null, values);
        db.close();
    }
}
