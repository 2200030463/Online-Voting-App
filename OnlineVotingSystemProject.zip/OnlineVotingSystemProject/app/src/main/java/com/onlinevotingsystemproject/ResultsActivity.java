package com.onlinevotingsystemproject;

import android.annotation.SuppressLint;
import android.os.Bundle;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultsActivity extends AppCompatActivity {

    private TextView resultsTextView;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        resultsTextView = findViewById(R.id.textView_results);
        dbHelper = new DatabaseHelper(this);

        displayResults();
    }

    private void displayResults() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT p." + DatabaseHelper.COLUMN_PARTY_NAME + ", COUNT(v." + DatabaseHelper.COLUMN_VOTE_ID + ") as count " +
                "FROM " + DatabaseHelper.TABLE_VOTES + " v " +
                "JOIN " + DatabaseHelper.TABLE_PARTIES + " p ON v." + DatabaseHelper.COLUMN_PARTY_ID_FK + " = p." + DatabaseHelper.COLUMN_PARTY_ID +
                " GROUP BY p." + DatabaseHelper.COLUMN_PARTY_NAME;
        Cursor cursor = db.rawQuery(query, null);

        StringBuilder results = new StringBuilder();
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String partyName = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PARTY_NAME));
            @SuppressLint("Range") int count = cursor.getInt(cursor.getColumnIndex("count"));
            results.append(partyName).append(": ").append(count).append(" votes\n\n");
        }
        cursor.close();
        db.close();
        resultsTextView.setText(results.toString());
    }
}
